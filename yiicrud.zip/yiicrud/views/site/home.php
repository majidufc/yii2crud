<?php
use yii\helpers\html;
/* @var $this yii\web\View */

$this->title = 'yii2 crud application';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1 style="color: #ff0039;">yii2 crud application</h1>

        
    </div>

    <div class="body-content">
         <span style="margin-bottom: 20px;"><?= Html::a('create',['create'],['class' => 'btn btn-primary '])?><span>
         </div> 
       <div class="row">
      <table class="table table-hover">
      <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Attendance</th>
        <th scope="col">Abbsent</th>
        <th scope="col">Canceled</th>
        <th scope="col">Actions</th>
     </tr>
   </thead>
   <tbody>
       <?php if(count($reports) > 0 ){ ?>
            <?php foreach($reports as $report){?>
       <tr class="table-active">
        <th scope="row"><?= $report->id;?></th>
        <td><?= $report->attendance;?></td>td>
        <td><?= $report->absent;?></td>td>
        <td><?= $report->canceled;?></td>td>
       <td>
        <span><?= Html ::a('View') ?></span>
        <span><?= Html ::a('Delete') ?></span>
        <span><?= Html ::a('Update') ?></span>
      </td>
     </tr>
         <?php } } ?>
        </tbody>
      </table>
   </div>

  </div>
</div>