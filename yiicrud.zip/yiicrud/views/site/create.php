<?php

/* @var $this yii\web\View */

$this->title = 'yii2 crud applications';
?>
<div class="site-index">


    <div class="body-content">

            
    <form action="/reportsinserts">
      <label for="fname">First name:</label><br>
      <input type="text" id="fname" name="fname" placeholder="first name"><br>
      <label for="mname">middle name:</label><br>
      <input type="text" id="middlename" name="mname" placeholder="middle name"><br>
      <label for="lname">Last name:</label><br>
      <input type="text" id="lname" name="lname" placeholder="Last name"><br>
      <input type="button" value="Submit">
    </form> 
    </div>
</div>
