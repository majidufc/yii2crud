<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "reports".
 *
 * @property int $id
 * @property string $attendance
 * @property string $abbsent
 * @property string $canceled
 */
class Reports extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'reports';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'attendance', 'absent', 'canceled'], 'required'],
            [['id'], 'integer'],
            [['attendance', 'absent', 'canceled'], 'string', 'max' => 100],
            [['id'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'attendance' => 'Attendance',
            'absent' => 'Absent',
            'canceled' => 'Canceled',
        ];
    }
}
